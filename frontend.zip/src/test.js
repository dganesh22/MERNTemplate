const images = {
    logo: "logo512.png"
}

export default images
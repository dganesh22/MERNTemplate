import React from 'react'
import images from '../../test'

function Home() {
  return (
    <div className='container'>
        <div className="row">
            <div className="col-md-12 text-center">
                <h3 className="display-3 text-success">Home</h3>
            </div>
        </div>
        <div className="row">
          <div className="col-md-12">
              
          </div>
        </div>
    </div>
  )
}

export default Home
